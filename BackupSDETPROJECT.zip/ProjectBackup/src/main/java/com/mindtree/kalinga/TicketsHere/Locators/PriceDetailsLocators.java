package com.mindtree.kalinga.TicketsHere.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PriceDetailsLocators 
{
	/*@FindBy(linkText="Movies")
	public
	WebElement movie;
	@FindBy(xpath="//*[@id='films']/div[2]/div/div[2]/div/div[1]/div/div[2]/input")
	public
	WebElement book;*/
	@FindBy(xpath="//*[@id='one_ish']/div/div[2]/div[1]/p/button")
	public 
	WebElement pay;
	
	
}
