package com.mindtree.kalinga.TicketsHere.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class NetBankingLocators 
{
	@FindBy(xpath="//form/div[2]/input")
	public 
	WebElement userName;
	
	@FindBy(xpath="//form/div[3]/input")
	public 
	WebElement password;
	
	@FindBy(xpath="//form/div[4]/button")
	public
	WebElement pay;
}
