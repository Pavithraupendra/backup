package com.mindtree.kalinga.TicketsHere.Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.Base.HelperElements;
import com.mindtree.kalinga.TicketsHere.Locators.ModeOfPaymentLocators;
import com.mindtree.kalinga.TicketsHere.Locators.TimingsPageLocators;
import com.mindtree.kalinga.TicketsHere.reports.Reporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class ModeOfPaymentAction {
	WebDriver driver1=Browsers.driver;
	
	 ModeOfPaymentLocators  mode=PageFactory.initElements(driver1, ModeOfPaymentLocators.class);
	   
 HelperElements h=PageFactory.initElements(driver1,HelperElements.class);
 String imgname;
	ExtentReports report;
	ExtentTest log;
	boolean clean;
	Reporter extreports = new Reporter();
	
	public void netbanking()
	{
		h.clickButton(mode.netBanking);
	}
	public void debit()
	{
		h.clickButton(mode.debit);
	}


}
