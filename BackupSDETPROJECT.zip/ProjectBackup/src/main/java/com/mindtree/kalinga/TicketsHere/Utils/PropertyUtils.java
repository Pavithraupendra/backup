package com.mindtree.kalinga.TicketsHere.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.swing.Spring;

/**
 * 
 * @author [your name]
 *
 */

public class PropertyUtils {

	Properties prop = new Properties();
	String FilePath = "./src/Browsers/java/config.properties";

	public String getChromePath() throws IOException {

		InputStream input = new FileInputStream(FilePath);

		prop.load(input);
		String ChromeDriver = prop.getProperty("ChromeDriver");
	
		return ChromeDriver;

	}

	public String getChromeDrivername() throws IOException {

		InputStream input = new FileInputStream(FilePath);
		prop.load(input);
		String chromedrivername = prop.getProperty("chromedrivername");

		return chromedrivername;

	}
	
	public String getFireFoxPath() throws IOException {
		InputStream input = new FileInputStream(FilePath);

		prop.load(input);
		String FirefoxDriver = prop.getProperty("FirefoxDriver");

		
		return FirefoxDriver;
		
		

		
	}
	public String getFireFoxDrivername() throws IOException {
		InputStream input = new FileInputStream(FilePath);

		prop.load(input);
		String FirefoxDrivername = prop.getProperty("firefoxdrivername");

		
		return FirefoxDrivername;
		
		

		
	}
	public String getIEPath() throws IOException {
		InputStream input = new FileInputStream(FilePath);

		prop.load(input);
		String IEpath = prop.getProperty("IeDriver");

		
		return IEpath;
		
		

		
	}
	public String getIEDrivername() throws IOException {
		InputStream input = new FileInputStream(FilePath);

		prop.load(input);
		String IEDrivername = prop.getProperty("IeDrivername");

		
		return IEDrivername;
		
		

		
	}
	public String geturl() throws IOException {

		InputStream input = new FileInputStream(FilePath);
		prop.load(input);
		String url = prop.getProperty("url");

	
		return url;
	}


	
	  public String readFromPropertyFile(String key) throws Exception{
		  InputStream input = new FileInputStream(FilePath);
	  prop.load(input); 
	  String str=prop.getProperty(key);
	  return str;
	  
	  }
	  
	  
	  public void writingToPropertyFile(String key, String value) throws Exception{
		  InputStream input = new FileInputStream(FilePath);
		  prop.load(input); 
		  prop.setProperty(key, value);
	  prop.store(new FileOutputStream(FilePath), "save");
	  }

	
	 

}
