package com.mindtree.kalinga.TicketsHere.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SeatSelectionLocators 
{
	@FindBy(xpath="")
	public
    WebElement noOfSeats;
	
	@FindBy(xpath="")
	public 
	WebElement seat1;
	
	@FindBy(xpath="")
	public 
	WebElement seat2;
	
	@FindBy(xpath="")
	public 
	WebElement seat3;
	
	@FindBy(xpath="")
	public 
	WebElement buyTicket;
	
   
}
