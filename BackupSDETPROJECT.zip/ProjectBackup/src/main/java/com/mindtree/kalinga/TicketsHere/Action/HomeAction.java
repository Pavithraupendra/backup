package com.mindtree.kalinga.TicketsHere.Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.Base.HelperElements;
import com.mindtree.kalinga.TicketsHere.Locators.HomeLocators;
import com.mindtree.kalinga.TicketsHere.reports.Reporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class HomeAction {
	WebDriver driver1=Browsers.driver;
	
	 HomeLocators home=PageFactory.initElements(driver1,HomeLocators.class);
	   
    HelperElements h=PageFactory.initElements(driver1,HelperElements.class);
    String imgname;
	ExtentReports report;
	ExtentTest log;
	boolean clean;
	Reporter extreports = new Reporter();
	
	public void clickmovies()
	{
		h.clickButton(home.movies);
	}

}
