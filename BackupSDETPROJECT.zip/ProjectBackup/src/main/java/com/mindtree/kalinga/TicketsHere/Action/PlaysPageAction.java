package com.mindtree.kalinga.TicketsHere.Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.Base.HelperElements;
import com.mindtree.kalinga.TicketsHere.Locators.NetBankingLocators;
import com.mindtree.kalinga.TicketsHere.Locators.PlaysPageLocators;
import com.mindtree.kalinga.TicketsHere.reports.Reporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class PlaysPageAction {
	
	
	WebDriver driver1=Browsers.driver;
	
	PlaysPageLocators details=PageFactory.initElements(driver1, PlaysPageLocators.class);
		   
	HelperElements h=PageFactory.initElements(driver1,HelperElements.class);
	
		ExtentReports report;
		ExtentTest log;
		boolean clean;
		Reporter extreports = new Reporter();
		
		
		public void bookNow()
		{
			h.clickButton(details.bookNow);
		}


}
