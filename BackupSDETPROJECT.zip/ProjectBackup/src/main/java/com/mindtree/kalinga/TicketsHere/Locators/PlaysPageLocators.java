package com.mindtree.kalinga.TicketsHere.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PlaysPageLocators {
	
	
	@FindBy(xpath="//*[@id='plays']/div[2]/div/div[2]/div/div[1]/div/div/input")
	public 
	WebElement bookNow ;

}
