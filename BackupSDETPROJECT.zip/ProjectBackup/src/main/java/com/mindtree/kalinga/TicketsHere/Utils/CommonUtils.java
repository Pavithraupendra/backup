package com.mindtree.kalinga.TicketsHere.Utils;

/**
 * 
 * @author [your name]
 *
 */

public class CommonUtils {

}
