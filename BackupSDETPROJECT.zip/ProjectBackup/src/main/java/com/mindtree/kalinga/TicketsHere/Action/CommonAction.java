package com.mindtree.kalinga.TicketsHere.Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.Base.HelperElements;
import com.mindtree.kalinga.TicketsHere.reports.*;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
/**
 * 
 * @author [your name]
 *
 */

public class CommonAction 
{
	WebDriver driver1=Browsers.driver;
	
       
   
	    HelperElements h=PageFactory.initElements(driver1,HelperElements.class);
	    String imgname;
		ExtentReports report;
		ExtentTest log;
		boolean clean;
		Reporter extreports = new Reporter();
	
		
	    public void firstName(String firstname)
	    {
	    h.setText(h.firstname, firstname);
	    }
	    
	    public void lastname(String lastname)
	    {
	    h.setText(h.lastname, lastname);
	    }
	    public void username(String username)
	    {
	    h.setText(h.username, username);
	    }
	    public void password(String password)
	    {
	    h.setText(h.password,password);
	    }
	    public void passwordagain(String passwordagain)
	    {
	    h.setText(h.passwordagain, passwordagain);
	    }
	    public void birthday(String birthday)
	    {
	    h.setText(h.birthday, birthday);
	    }
	    public void birthmonth(String birthmonth)
	    {
	    h.selectByVisibleText(h.birthmonth , birthmonth);
	    }
	    public void birthyear(String birthyear)
	    {
	    h.setText(h.birthyear, birthyear);
	    }
	    public void gender(String gender)
	    {
	    h.selectByVisibleText(h.gender, gender);
	    }
	    public void recoveryphone(String recoveryphone)
	    {
	    h.setText(h.recoveryphone, recoveryphone);
	    }
	    public void recoveryemail(String recoveryemail)
	    {
	    h.setText(h.recoveryemail, recoveryemail);
	    }
	    public void location(String location)
	    {
	    h.selectByVisibleText(h.location, location);
	    }
	    public void click()
	    {
	    h.clickButton(h.nextStep);
	    }
	    
	   public void signUp(String firstname,String lastname,String mail,String password,String birthday,String birthyear,String mobile,String e_mail)
	   {
	    firstName(firstname);
		lastname(lastname);
		username(mail);
		password(password);
		passwordagain(password);
		birthday(birthday);
		//birthmonth(birthmonth);
		birthyear(birthyear);
		//gender(gender);
		recoveryphone(mobile);
		recoveryemail(e_mail);
		click();
	   }
	   

   }

