package com.mindtree.kalinga.TicketsHere.Base;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.mindtree.kalinga.TicketsHere.Test.Sanity.Testcase1;
import com.mindtree.kalinga.TicketsHere.Utils.PropertyUtils;

/**
 * 
 * @author M1043081
 *
 */

public class Browsers {

	public static WebDriver driver;
	static PropertyUtils p = new PropertyUtils();

	public static WebDriver openchrome() throws IOException {

		String chromepath = p.getChromePath();
		String chromedrivername = p.getChromeDrivername();
		String url = p.geturl();

		System.setProperty(chromedrivername, chromepath);
		driver = new ChromeDriver();

		return driver;

	}

	public static WebDriver openfirefox() throws IOException {

		String FireFoxpath = p.getFireFoxPath();
		String FireFoxdrivername = p.getFireFoxDrivername();
		String url = p.geturl();

		System.setProperty(FireFoxdrivername, FireFoxpath);
		
		System.setProperty("webdriver.firefox.bin", "./src/Browsers/java/firefox.exe");
		driver = new FirefoxDriver();
		return driver;
	}

	public static WebDriver openie() throws IOException {

		String IEpath = p.getIEPath();
		String IEdrivername = p.getIEDrivername();
		String url = p.geturl();
		System.setProperty(IEdrivername, IEpath);
		driver = new InternetExplorerDriver();
		System.out.println("hi you are in ie");
		return driver;
	}

}
