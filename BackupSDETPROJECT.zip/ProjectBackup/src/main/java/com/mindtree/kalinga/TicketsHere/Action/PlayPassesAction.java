package com.mindtree.kalinga.TicketsHere.Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.Base.HelperElements;
import com.mindtree.kalinga.TicketsHere.Locators.PlayPassesLocators;
import com.mindtree.kalinga.TicketsHere.Locators.PlaysPageLocators;
import com.mindtree.kalinga.TicketsHere.reports.Reporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class PlayPassesAction {
	
WebDriver driver1=Browsers.driver;
	
	PlayPassesLocators details=PageFactory.initElements(driver1, PlayPassesLocators.class);
		   
	HelperElements h=PageFactory.initElements(driver1,HelperElements.class);
	
		ExtentReports report;
		ExtentTest log;
		boolean clean;
		Reporter extreports = new Reporter();
		
		
		public void entryPass()
		{
			h.clickButton(details.entryPass);
		}

		public void number()
		{
			h.clickButton(details.number);
		}

}
