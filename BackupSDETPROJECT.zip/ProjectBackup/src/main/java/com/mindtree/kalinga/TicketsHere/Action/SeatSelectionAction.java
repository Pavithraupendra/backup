package com.mindtree.kalinga.TicketsHere.Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.Base.HelperElements;
import com.mindtree.kalinga.TicketsHere.Locators.MoviesPageLocators;
import com.mindtree.kalinga.TicketsHere.Locators.SeatSelectionLocators;
import com.mindtree.kalinga.TicketsHere.reports.Reporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public  class SeatSelectionAction {
	WebDriver driver1=Browsers.driver;
	
	SeatSelectionLocators  seat=PageFactory.initElements(driver1,SeatSelectionLocators .class);
	   
  HelperElements h=PageFactory.initElements(driver1,HelperElements.class);
  String imgname;
	ExtentReports report;
	ExtentTest log;
	boolean clean;
	Reporter extreports = new Reporter();
	
	
	public void noOfSeats()
	{
		h.clickButton(seat.noOfSeats);
	}
	
	public void clickseat1()
	{
		h.clickButton(seat.seat1);
	}
	public void clickseat2()
	{
		h.clickButton(seat.seat2);
	}
	public void buyticket()
	{
		h.clickButton(seat.buyTicket);
	}

	
	
	
	
}
