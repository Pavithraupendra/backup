package com.mindtree.kalinga.TicketsHere.Utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * 
 * @author [your name]
 *
 */

public class DBUtils {
	Connection conn= null;
	DBUtils startConnection;
	//Properties prop = new Properties();
	PropertyUtils prop;
	
		
	public Connection dbConnection() throws Exception{
		prop = new PropertyUtils();
		Class.forName(prop.readFromPropertyFile("JdbcDriver"));
	
		conn= DriverManager.getConnection(prop.readFromPropertyFile("mydbUrl"), prop.readFromPropertyFile("user"),prop.readFromPropertyFile("pass"));
		return conn;
	}
	
	
	public void dbDisconnection() throws Exception{
		conn.close();
}
	
	
	
	public Boolean queryBoolean(String query) throws Exception{
		startConnection = new DBUtils(); 
		Connection con=startConnection.dbConnection();
		Statement pst = con.createStatement();
		Boolean b = null;
		System.out.println(query);
		ResultSet rs = pst.executeQuery(query);
		//System.out.println(prop.getProperty("JdbcDriver"));
		while(rs.next()){
			b = rs.getBoolean(1);
		}
		startConnection.dbDisconnection();
		return b;
	}
	public String queryString(String query) throws Exception{
		startConnection = new DBUtils(); 
		Statement pst = startConnection.conn.prepareStatement(query);
		String st = null;
		ResultSet rs = pst.executeQuery(query);
		while(rs.next()){
		st= rs.getString(1);
		System.out.println(st);
		}
		return st;
	}
	
	public  ArrayList<Object> queryRow(String query) throws Exception{
		ArrayList<Object> al = new ArrayList<>();
		startConnection = new DBUtils(); 
		PreparedStatement pst = startConnection.conn.prepareStatement(query);
		ResultSet rs = pst.executeQuery(query);
		while(rs.next()){
		al.add(rs.getString(1));
		}
		return al;
	}


}
