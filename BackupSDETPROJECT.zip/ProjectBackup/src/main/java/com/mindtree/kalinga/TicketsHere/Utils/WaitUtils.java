package com.mindtree.kalinga.TicketsHere.Utils;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mindtree.kalinga.TicketsHere.Base.Browsers;

/**
 * 
 * @author M1043081
 *
 */

public class WaitUtils {
WebDriver driver2=Browsers.driver;
	
	//IMPLICIT WAIT
	  public void implicitwait() throws Exception {
	    
	    driver2.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	  }
	  
	  //EXPLICIT WAIT
	
	  public void explicitwait() throws Exception {
		    
		    driver2.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		  }
	  
	  //WAIT FOR ELEMENT
	  
	  public void waitforelement() throws Exception{
		  WebDriverWait wait = new WebDriverWait(driver2, 15);
		  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("path")));
	  }
	  
	  //PAGE REFRESH
	  
	  public void pagerefresh() throws Exception{
		  driver2.navigate().refresh();
	  }
	  
		//Refresh via F5
				public void keyRefresh(WebDriver driver){
					Actions actions = new Actions(driver);
					actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).build().perform();
				}
				//Reload the page
				public void keyReload(WebDriver driver){
					Actions actions = new Actions(driver);
					actions.keyDown(Keys.CONTROL).sendKeys(Keys.F5).build().perform();
				} 
		 
			//Page loading
				public void pageload(WebDriver driver, int time,String unit){
					if(unit.equalsIgnoreCase("seconds"))
					driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
					else if(unit.equalsIgnoreCase("milliseconds"))
						driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.MILLISECONDS);
				} 

	  

	

}
