package com.mindtree.kalinga.TicketsHere.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ChooseBankLocators 
{
	@FindBy(xpath="//div/div[1]/a[4]/input")
	public 
	WebElement bank;
}
