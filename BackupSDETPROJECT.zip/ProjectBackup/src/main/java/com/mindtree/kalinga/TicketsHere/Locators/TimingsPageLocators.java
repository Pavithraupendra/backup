package com.mindtree.kalinga.TicketsHere.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TimingsPageLocators {
	@FindBy(xpath="/html/body/app-root/app-movie-theatre-details/div/div[3]/div/div[2]/table/tbody/tr[1]/td[2]/label[1]")
	public
    WebElement timings;

}