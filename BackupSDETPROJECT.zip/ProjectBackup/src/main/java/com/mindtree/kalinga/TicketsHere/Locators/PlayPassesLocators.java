package com.mindtree.kalinga.TicketsHere.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PlayPassesLocators {
	

	@FindBy(xpath="//*[@id='show']")
	public
    WebElement entryPass;
	
	
	@FindBy(xpath="//*[@id='h']/th[2]/label")
	public
    WebElement number;
	
	

}
