package com.mindtree.kalinga.TicketsHere.Base;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * 
 * @author M1043081
 *
 */
public class Browseralerts {
	WebDriver driver = Browsers.driver;
	public void SimpleAlert() {
		
		
		// This step will result in an alert on screen
		driver.findElement(By.xpath("xpath")).click();
 
		Alert simpleAlert = driver.switchTo().alert();
		String alertText = simpleAlert.getText();
		System.out.println("Alert text is " + alertText);
		simpleAlert.accept();
	}
	
	public void ConfirmationAlert() {
		
		// This step will result in an alert on screen
		
 
		Alert confirmationAlert = driver.switchTo().alert();
		String alertText = confirmationAlert.getText();
		System.out.println("Alert text is " + alertText);
		confirmationAlert.dismiss();
	}
	public void PromptAlert() throws InterruptedException
	{
		// This step will result in an alert on screen
		WebElement element = driver.findElement(By.xpath("xpath"));
		((JavascriptExecutor) driver).executeScript("arguments[0].click()", element);
 
		Alert promptAlert  = driver.switchTo().alert();
		String alertText = promptAlert .getText();
		System.out.println("Alert text is " + alertText);
		//Send some text to the alert
		promptAlert .sendKeys("Accepting the alert");
		Thread.sleep(4000); //This sleep is not necessary, just for demonstration
		promptAlert .accept();
	}
	
	
}
