package com.mindtree.kalinga.TicketsHere.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomeLocators 
{
	//@FindBy(xpath="/html/body/app-root/app-header/nav/div/div[2]/ul[1]/li[2]/a")
	@FindBy(xpath="//ul[1]/li[2]/a")
	public
    WebElement movies;
}
