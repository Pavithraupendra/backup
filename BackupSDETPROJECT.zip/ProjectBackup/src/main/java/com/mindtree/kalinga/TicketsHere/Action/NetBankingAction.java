package com.mindtree.kalinga.TicketsHere.Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.Base.HelperElements;
import com.mindtree.kalinga.TicketsHere.Locators.ChooseBankLocators;
import com.mindtree.kalinga.TicketsHere.Locators.NetBankingLocators;
import com.mindtree.kalinga.TicketsHere.reports.Reporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class NetBankingAction {
WebDriver driver1=Browsers.driver;
	
NetBankingLocators  details=PageFactory.initElements(driver1, NetBankingLocators.class);
	   
HelperElements h=PageFactory.initElements(driver1,HelperElements.class);
String imgname;
	ExtentReports report;
	ExtentTest log;
	boolean clean;
	Reporter extreports = new Reporter();
	
	public void username(String username)
	{
		h.setText(details.userName, username);
	}
	public void password(String password)
	{
		h.setText(details.password, password);
	}
	public void pay()
	{
		h.clickButton(details.pay);
	}

}
