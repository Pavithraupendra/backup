package com.mindtree.kalinga.TicketsHere.Interface;

/**
 * 
 * @author [your name]
 *
 */

public class CommonInterface {

}
