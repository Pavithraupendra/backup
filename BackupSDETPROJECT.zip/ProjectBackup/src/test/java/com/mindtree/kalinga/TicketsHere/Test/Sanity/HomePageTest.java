package com.mindtree.kalinga.TicketsHere.Test.Sanity;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.mindtree.kalinga.TicketsHere.Action.HomeAction;
import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.helper.TestHelper;
import com.mindtree.kalinga.TicketsHere.reports.Reporter;
import com.relevantcodes.extentreports.ExtentTest;



public class HomePageTest extends TestHelper {
	public static WebDriver driver;

@Parameters("browser")

  @Test
  public void f(String browsername) throws Exception {

		if (browsername.equalsIgnoreCase("chrome")) {
			 driver = Browsers.openchrome();
		} 
		else if(browsername.equalsIgnoreCase("firefox"))
		{
			driver=Browsers.openfirefox();
		}
		driver.manage().window().maximize();
	    driver.get("http://172.17.120.240:5600");
		
		
	  HomeAction home=PageFactory.initElements(driver,HomeAction.class);
	  home.clickmovies();
	  
	  
	  
  	
  }
}
