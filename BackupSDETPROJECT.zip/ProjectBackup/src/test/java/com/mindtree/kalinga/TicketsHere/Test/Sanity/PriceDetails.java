package com.mindtree.kalinga.TicketsHere.Test.Sanity;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.mindtree.kalinga.TicketsHere.Action.PlaysPageAction;
import com.mindtree.kalinga.TicketsHere.Action.PriceDetailsAction;
import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.reports.Reporter;
import com.relevantcodes.extentreports.ExtentTest;

public class PriceDetails {
	public  WebDriver driver;

	Reporter report = new Reporter();
	ExtentTest log;

	@BeforeTest
	public void setupReports(){
	log=report.setupReports();
	}
		@Parameters("browser")

		@Test
		public void sample(String browsername) throws IOException {

		

			if (browsername.equalsIgnoreCase("chrome")) {
				 driver = Browsers.openchrome();
			} 
			else if(browsername.equalsIgnoreCase("firefox"))
			{
				driver=Browsers.openfirefox();
			}
			driver.manage().window().maximize();
			driver.get("http://172.17.120.240:5600/seat");
			
			
				
			//p.clickmovies();
			
			List<WebElement> liElements = driver.findElements(By.xpath("//ul[@class='book-right']/li"));
			
	        System.out.println(liElements.size());
	        WebElement linkElement;
	        for (int i = 1; i < liElements.size()+1; i++) {
	            linkElement = driver.findElement(By.xpath("//ul[@class='book-right']/li["+i+"]")); //("//ul[@id='browse-new-product']/li["+i+"]/a"));
	            System.out.println(linkElement.getText());
	        }
	        
	       String ui = liElements.get(2).getText();
	       
	       
	        System.out.println(ui);
        	driver.get("http://172.17.120.240:5600/book");
	        PriceDetailsAction p = PageFactory.initElements(driver, PriceDetailsAction.class);
	        int NoOfTickets = 4;
	        //cost calculation
	        String cost = driver.findElement(By.xpath("//table[@class='table borderless']/tbody/tr[2]/td[2]")).getText();
	        System.out.println(cost);
	        int s = Integer.parseInt(cost.substring(3,cost.length()));
	        System.out.println(s);
	        if(s==NoOfTickets*120)
	        {
	        	//System.out.println((NoOfTickets*150));
	        	System.out.println("Cost is correctly calculated");
	        }
	        else
	        {
	        	System.out.println("Cost is not calculated correctly");
	        }
	        
	        System.out.println();
	        //booking calculation
	        String book = driver.findElement(By.xpath("//table[@class='table borderless']/tbody/tr[4]/td[2]")).getText();
	        System.out.println(book);
	        int s1 = Integer.parseInt(book.substring(3,cost.length()));
	        System.out.println(s1);
	        if(s1==NoOfTickets*25)
	        {
	        	//System.out.println((NoOfTickets*150));
	        	System.out.println("Booking is correctly calculated");
	        }
	        else
	        {
	        	System.out.println("Booking is not calculated correctly");
	        }
	        
	        System.out.println();
	        //GST calculation
	        String gst = driver.findElement(By.xpath("//table[@class='table borderless']/tbody/tr[5]/td[2]")).getText();
	        System.out.println(gst);
	        int s2 = Integer.parseInt(gst.substring(3,gst.length()));
	        System.out.println(s2);
	        if(s2==((NoOfTickets*25)/100)*18)
	        {
	        	//System.out.println((NoOfTickets*150));
	        	System.out.println("GST is correctly calculated");
	        }
	        else
	        {
	        	System.out.println("GST is not calculated correctly");
	        }
	        
	        System.out.println();
	        //Internet Handling Charges calculation
	        String ihc = driver.findElement(By.xpath("//table[@class='table borderless']/tbody/tr[3]/td[2]")).getText();
	        System.out.println(ihc);
	        int s3 = Integer.parseInt(ihc.substring(3,ihc.length()));
	        System.out.println(s3);
	        if(s3== ((NoOfTickets*25)+((NoOfTickets*25)/100)*18))
	        {
	        	//System.out.println((NoOfTickets*150));
	        	System.out.println("Internet Handling Charges is correctly calculated");
	        }
	        else
	        {
	        	System.out.println("Internet Handling Charges is not calculated correctly");
	        }
	        
	        System.out.println();
	        //Total cost calculation
	        String tc = driver.findElement(By.xpath("//table[@class='table borderless']/tbody/tr[6]/td[2]")).getText();
	        System.out.println(tc);
	        int s4 = Integer.parseInt(tc.substring(3,tc.length()));
	        System.out.println(s4);
	        if(s4== ((NoOfTickets*25)+((NoOfTickets*25)/100)*18)+(NoOfTickets*150))
	        {
	        	//System.out.println((NoOfTickets*150));
	        	System.out.println("Total Cost is correctly calculated");
	        }
	        else
	        {
	        	System.out.println("Total Cost is not calculated correctly");
	        }
	        
	        
	        //Pay Button Validation
	        String paybtn = driver.findElement(By.xpath("//button[@class='button']")).getText();
	        System.out.println(paybtn);
	        
	        int s5 = Integer.parseInt(paybtn.substring(7,paybtn.length()));
	        System.out.println(s5);
	        if(s5== ((NoOfTickets*25)+((NoOfTickets*25)/100)*18)+(NoOfTickets*150))
	        {
	        	//System.out.println((NoOfTickets*150));
	        	System.out.println("pay Cost is correctly calculated");
	        }
	        else
	        {
	        	System.out.println("pay Cost is not calculated correctly");
	        }
	        
	        
			p.clickmovies();
			
		}
			
}
