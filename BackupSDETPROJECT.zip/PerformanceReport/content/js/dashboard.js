/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 95.46991210277214, "KoPercent": 4.530087897227856};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9536812996889042, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)  ", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "signInDetails"], "isController": true}, {"data": [1.0, 500, 1500, "151 /user/signIn"], "isController": false}, {"data": [1.0, 500, 1500, "156 /user/signIn"], "isController": false}, {"data": [1.0, 500, 1500, "signOut"], "isController": true}, {"data": [1.0, 500, 1500, "157 /"], "isController": false}, {"data": [1.0, 500, 1500, "signInPage"], "isController": true}, {"data": [1.0, 500, 1500, "148 /user/signOut"], "isController": false}, {"data": [1.0, 500, 1500, "productDetails"], "isController": true}, {"data": [1.0, 500, 1500, "145 /user/signUp"], "isController": false}, {"data": [1.0, 500, 1500, "signUpDetails"], "isController": true}, {"data": [1.0, 500, 1500, "140 /user/signUp"], "isController": false}, {"data": [1.0, 500, 1500, "signUpPage"], "isController": true}, {"data": [1.0, 500, 1500, "159 /product/detail"], "isController": false}, {"data": [0.0, 500, 1500, "addToCart"], "isController": true}, {"data": [0.0, 500, 1500, "161 /order/addToCart"], "isController": false}, {"data": [1.0, 500, 1500, "163 /user/signOut"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1479, 67, 4.530087897227856, 10.660581473968897, 1, 706, 22.0, 29.0, 43.40000000000009, 15.71398215044624, 56.59749314372609, 8.255667631746705], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["signInDetails", 68, 0, 0.0, 45.66176470588237, 18, 253, 54.0, 87.19999999999987, 253.0, 0.7467111765093448, 17.46430387713307, 0.8391707319416687], "isController": true}, {"data": ["151 /user/signIn", 68, 0, 0.0, 9.352941176470585, 4, 22, 13.0, 16.099999999999994, 22.0, 0.7467849808361795, 4.64618187303008, 0.34410322998231874], "isController": false}, {"data": ["156 /user/signIn", 68, 0, 0.0, 12.573529411764703, 5, 92, 15.100000000000001, 19.19999999999999, 92.0, 0.7468341918265587, 0.10502355822560983, 0.4761775852269607], "isController": false}, {"data": ["signOut", 425, 0, 0.0, 4.007058823529414, 0, 32, 6.0, 6.0, 12.740000000000009, 4.520074448285031, 0.6341398564211645, 2.093047892847647], "isController": true}, {"data": ["157 /", 68, 0, 0.0, 33.08823529411766, 11, 161, 40.1, 72.94999999999986, 161.0, 0.746858799753976, 17.362729514926194, 0.3631433591347421], "isController": false}, {"data": ["signInPage", 68, 0, 0.0, 9.36764705882353, 4, 22, 13.0, 16.099999999999994, 22.0, 0.7468259895444362, 4.646437011954707, 0.34412212595549796], "isController": true}, {"data": ["148 /user/signOut", 357, 0, 0.0, 3.663865546218486, 1, 18, 5.0, 6.0, 12.420000000000016, 3.7968625365594257, 0.5339337942036692, 1.7535229992023398], "isController": false}, {"data": ["productDetails", 68, 0, 0.0, 18.382352941176467, 0, 49, 23.200000000000003, 33.69999999999996, 49.0, 0.7470885519666007, 4.695074743188311, 0.3505732771643595], "isController": true}, {"data": ["145 /user/signUp", 358, 0, 0.0, 6.656424581005583, 3, 36, 9.0, 10.0, 22.82000000000005, 3.8071335899780934, 0.5353781610906693, 2.4851279690058914], "isController": false}, {"data": ["signUpDetails", 359, 0, 0.0, 6.637883008356542, 0, 36, 9.0, 10.0, 22.799999999999955, 3.817727441909927, 0.5353724676981975, 2.485101541314404], "isController": true}, {"data": ["140 /user/signUp", 359, 0, 0.0, 11.515320334261837, 4, 85, 15.0, 18.0, 66.5999999999998, 3.8148876255246797, 24.759213860182772, 1.7534332494288294], "isController": false}, {"data": ["signUpPage", 359, 0, 0.0, 11.529247910863504, 4, 85, 15.0, 18.0, 66.5999999999998, 3.812942763374507, 24.746591402424777, 1.7525393342485103], "isController": true}, {"data": ["159 /product/detail", 67, 0, 0.0, 18.656716417910445, 7, 49, 23.400000000000006, 34.39999999999992, 49.0, 0.7520822575937858, 4.797001808645579, 0.3581839984677727], "isController": false}, {"data": ["addToCart", 67, 67, 100.0, 38.16417910447762, 12, 706, 36.400000000000006, 46.39999999999995, 706.0, 0.751955645840114, 5.007846169655784, 0.46990651760361835], "isController": true}, {"data": ["161 /order/addToCart", 67, 67, 100.0, 38.16417910447762, 12, 706, 36.400000000000006, 46.39999999999995, 706.0, 0.751955645840114, 5.007846169655784, 0.46990651760361835], "isController": false}, {"data": ["163 /user/signOut", 67, 0, 0.0, 5.880597014925374, 2, 32, 7.0, 7.599999999999994, 32.0, 0.7519978450211009, 0.1057496969560923, 0.3583082082809554], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Test failed: text expected to contain \/camera1\/", 67, 100.0, 4.530087897227856], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1479, 67, "Test failed: text expected to contain \/camera1\/", 67, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["161 /order/addToCart", 67, 67, "Test failed: text expected to contain \/camera1\/", 67, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
