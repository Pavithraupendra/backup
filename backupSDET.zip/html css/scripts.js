function fun()
{
	var fname = document.getElementById("firstname");
	var pattern1 = fname.value.search([A-Z]);
	if(pattern1!=0)
	{
		alert("Invalid Firstname");
	}
}