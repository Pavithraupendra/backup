/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 89.39102564102564, "KoPercent": 10.60897435897436};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8850893942023954, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)  ", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "loadingPage"], "isController": true}, {"data": [0.9950124688279302, 500, 1500, "33 /user/signOut"], "isController": false}, {"data": [1.0, 500, 1500, "19 /"], "isController": false}, {"data": [1.0, 500, 1500, "15 /user/signUp"], "isController": false}, {"data": [1.0, 500, 1500, "18 /user/signOut"], "isController": false}, {"data": [0.9975186104218362, 500, 1500, "27 /"], "isController": false}, {"data": [0.9975124378109452, 500, 1500, "productDetail"], "isController": true}, {"data": [1.0, 500, 1500, "7 /"], "isController": false}, {"data": [1.0, 500, 1500, "21 /user/signIn"], "isController": false}, {"data": [0.18453865336658354, 500, 1500, "31 /order/addToCart"], "isController": false}, {"data": [0.9958071278825996, 500, 1500, "signOut"], "isController": true}, {"data": [1.0, 500, 1500, "signInPage"], "isController": true}, {"data": [1.0, 500, 1500, "signUp"], "isController": true}, {"data": [1.0, 500, 1500, "signUpDetails"], "isController": true}, {"data": [1.0, 500, 1500, "26 /user/signIn"], "isController": false}, {"data": [0.9975124378109452, 500, 1500, "29 /product/detail"], "isController": false}, {"data": [0.9975186104218362, 500, 1500, "signIn"], "isController": true}, {"data": [1.0, 500, 1500, "10 /user/signUp"], "isController": false}, {"data": [0.18453865336658354, 500, 1500, "addToCart"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 3120, 331, 10.60897435897436, 14.487500000000013, 1, 130, 28.0, 36.0, 53.0, 71.40895358418017, 594.130370333814, 36.438172677492446], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["loadingPage", 403, 0, 0.0, 28.193548387096783, 6, 121, 46.0, 53.0, 69.95999999999998, 9.25181937142726, 182.36102452277373, 3.859034943984022], "isController": true}, {"data": ["33 /user/signOut", 401, 2, 0.49875311720698257, 2.4862842892768087, 1, 11, 4.0, 5.0, 8.0, 9.191555687991382, 1.4058721519930317, 4.35774255334999], "isController": false}, {"data": ["19 /", 76, 0, 0.0, 20.697368421052623, 8, 74, 32.599999999999994, 41.19999999999993, 74.0, 1.763668430335097, 34.76349021425091, 0.7937459751810081], "isController": false}, {"data": ["15 /user/signUp", 76, 0, 0.0, 5.828947368421051, 2, 19, 10.299999999999997, 12.149999999999991, 19.0, 1.7641187530465867, 0.24807919964717623, 1.1503811497527912], "isController": false}, {"data": ["18 /user/signOut", 76, 0, 0.0, 3.4473684210526305, 1, 12, 7.0, 11.0, 12.0, 1.7643235212183117, 0.2481079951713251, 0.8147164676966292], "isController": false}, {"data": ["27 /", 403, 1, 0.24813895781637718, 23.186104218362285, 8, 130, 34.0, 39.799999999999955, 54.95999999999998, 9.2304168575355, 187.62467611944572, 4.4770447420407695], "isController": false}, {"data": ["productDetail", 402, 1, 0.24875621890547264, 14.763681592039799, 5, 39, 22.0, 25.0, 36.0, 9.209832985864509, 58.657267169637336, 4.374451412117116], "isController": true}, {"data": ["7 /", 403, 0, 0.0, 28.193548387096783, 6, 121, 46.0, 53.0, 69.95999999999998, 9.242483315368208, 182.1770031233516, 3.8551407729972706], "isController": false}, {"data": ["21 /user/signIn", 403, 0, 0.0, 10.610421836228278, 3, 43, 18.0, 21.799999999999955, 30.95999999999998, 9.235705282456744, 56.586733341927356, 4.256254834135442], "isController": false}, {"data": ["31 /order/addToCart", 401, 327, 81.54613466334165, 17.019950124688283, 6, 87, 27.80000000000001, 32.89999999999998, 55.98000000000002, 9.192398505375605, 61.220594103168054, 5.7444431549870485], "isController": false}, {"data": ["signOut", 477, 2, 0.4192872117400419, 5.937106918238987, 1, 82, 19.0, 27.0, 43.09999999999985, 10.933345557898598, 35.98720557182314, 5.946045257632713], "isController": true}, {"data": ["signInPage", 403, 0, 0.0, 10.61042183622828, 3, 43, 18.0, 21.799999999999955, 30.95999999999998, 9.235705282456744, 56.586733341927356, 4.256254834135442], "isController": true}, {"data": ["signUp", 76, 0, 0.0, 5.828947368421053, 2, 19, 10.299999999999997, 12.149999999999991, 19.0, 1.7641187530465867, 0.24807919964717623, 1.1503811497527912], "isController": true}, {"data": ["signUpDetails", 76, 0, 0.0, 8.421052631578945, 3, 24, 14.0, 19.14999999999999, 24.0, 1.7639549727283277, 11.281387808982243, 0.8128236697806661], "isController": true}, {"data": ["26 /user/signIn", 403, 0, 0.0, 8.794044665012411, 2, 26, 14.0, 17.0, 23.95999999999998, 9.235070351528485, 1.298681768183693, 5.895024297916954], "isController": false}, {"data": ["29 /product/detail", 402, 1, 0.24875621890547264, 14.7636815920398, 5, 39, 22.0, 25.0, 36.0, 9.210043988269796, 58.65861104031112, 4.3745516332363445], "isController": false}, {"data": ["signIn", 403, 1, 0.24813895781637718, 31.98014888337468, 11, 142, 46.0, 52.0, 64.91999999999996, 9.229359899232795, 188.9010702937135, 10.367911227527769], "isController": true}, {"data": ["10 /user/signUp", 76, 0, 0.0, 8.421052631578945, 3, 24, 14.0, 19.14999999999999, 24.0, 1.7639959149568285, 11.28164965532448, 0.8128425358021538], "isController": false}, {"data": ["addToCart", 401, 327, 81.54613466334165, 17.019950124688283, 6, 87, 27.80000000000001, 32.89999999999998, 55.98000000000002, 9.192398505375605, 61.220594103168054, 5.7444431549870485], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Test failed: text expected to contain \/Camera1\/", 327, 98.79154078549848, 10.48076923076923], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 4, 1.2084592145015105, 0.1282051282051282], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 3120, 331, "Test failed: text expected to contain \/Camera1\/", 327, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 4, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["33 /user/signOut", 401, 2, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["27 /", 403, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["31 /order/addToCart", 401, 327, "Test failed: text expected to contain \/Camera1\/", 327, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["29 /product/detail", 402, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
