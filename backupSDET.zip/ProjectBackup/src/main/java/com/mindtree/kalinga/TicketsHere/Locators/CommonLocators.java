package com.mindtree.kalinga.TicketsHere.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * 
 * @author [your name]
 *
 */

public class CommonLocators 
{
 	@FindBy(xpath="//*[@id=\"FirstName\"]")
	public
    WebElement firstname;
    
    @FindBy(xpath="//*[@id=\"LastName\"]")
    public 
    WebElement lastname;
    
    @FindBy(xpath="//*[@id=\"GmailAddress\"]")
    public
    WebElement username;
    
    @FindBy(xpath="//*[@id=\"Passwd\"]")
    public
    WebElement password;
    
    @FindBy(xpath="//*[@id=\"PasswdAgain\"]")
    public
    WebElement passwordagain;
    
    @FindBy(id="BirthMonth")
    public
    WebElement birthmonth;
    
    @FindBy(xpath="//*[@id='BirthDay']")
    public
    WebElement birthday;
    
    @FindBy(xpath="//input[@name='BirthYear']")
    public
    WebElement birthyear;
    
    @FindBy(xpath="//*[@id='Gender']/div[1]")
    public
    WebElement gender;
    
    @FindBy(xpath="//*[@id='RecoveryPhoneNumber']")
    public
    WebElement recoveryphone;
    
    @FindBy(xpath="//*[@id='RecoveryEmailAddress']")
    public
    WebElement recoveryemail;
    
    @FindBy(xpath="//*[@id=':i']")
    public
    WebElement location;
    
    @FindBy(xpath="//*[@id='submitbutton']")
    public
    WebElement nextStep;
    
    
}
