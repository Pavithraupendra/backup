package com.mindtree.kalinga.TicketsHere.reports;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;


/**
 * 
 * @author Pavithra Upendra
 *
 */

public class Assertions {

	static WebDriver driver;

	/**
	 * To check the title of the page
	 * @param actual
	 * @param expected
	 * @throws Exception
	 */
	public static void MatchTitle(String actual, String expected) throws Exception {
		try {
			assertEquals(actual, expected);
		} catch (Exception e) {
			throw new Exception("Title mis match exception: \n"+e.getMessage() );
		}
	}

	/**
	 * To check if the element is present on the screen
	 * @param xpat
	 * @return
	 */
	public static boolean isPresent(String xpat){
		
		if (driver.findElements(By.xpath(xpat)).size() != 0) 
		{
			return true;
		}else
			return false;
	}
	
	/**
	 * To check if the element is visible on the screen
	 * @param xpat
	 * @return
	 */
	
	public static boolean isVisible(String xpat){
		if(driver.findElement(By.xpath(xpat)).isDisplayed())
		{
			return true;
		}
		else 
			return false;
	}
	
	/**
	 * To check if the element is enabled
	 * @param xpat
	 * @return
	 */
	
	public static boolean isEnabled(String xpat){
		if(driver.findElement(By.xpath(xpat)).isEnabled())
		{
			return true;
		}
		else 
			return false;
	}
	
	/**
	 * To check if the button is click-able
	 * @param xpat
	 * @throws IOException
	 */
	public static void click(String xpat) throws IOException {
		if (isPresent(xpat)) 
		{

			if (isVisible(xpat)) 
			{
				if (isEnabled(xpat)) 
				{
					System.out.println("Button is Enable");
				} else {
					System.out.println("Element is Disabled");
				}
				WebElement web = driver.findElement(By.xpath(xpat));
				boolean bool = web.isDisplayed();
				Assert.assertEquals(true, bool);
				System.out.println("Button is Present");
				System.out.println("Button is Visible");
				screenShot(driver);
			} else {
				System.out.println("Button is InVisible");
				screenShot(driver);
			}
		} else {
			System.out.println("Button is Absent");
			screenShot(driver);
		}

	}

	/**
	 * To check if the sendKeys() method sends the correct input to the text box
	 * @param xpat
	 * @param key
	 */
	public static void sendKey(String xpat, String key) throws IOException {
		WebElement element = driver.findElement(By.xpath(xpat));
		element.sendKeys(key);
		try {
			Assert.assertEquals(element.getAttribute("value"), key);
			System.out.println("Sent keys for search matches");
			screenShot(driver);
		} catch (Exception e) {
			screenShot(driver);
			System.out.println("Sent keys don't match");
		}

	}

	
	/**
	 * TO compare the drop down elements
	 * @param list
	 * @param xpat
	 */
	public static void select(String[] list, String xpat) {
		WebElement dropdown = driver.findElement(By.xpath(xpat));
		Select select = new Select(dropdown);

		List<WebElement> options = select.getOptions();
		// for (WebElement we : options) {
		for (int i = 0; i < options.size(); i++) {
			try {
				Assert.assertEquals(list[i], options.get(i).getText());
				System.out.println("Matched");
			} catch (Exception e) {
				System.out.println("No Match");

			}

			// }
		}
	}
	
	/**
	 * 
	 * To compare elements in two lists
	 * @param l1
	 * @param l2
	 * @throws Exception
	 */
	//Implement searching
	public static void listCompare(List<Object> l1, List<Object> l2) throws Exception
	{
		try
		{
			for(int i=0; i<l1.size(); i++)
			{
				Assert.assertEquals(l1.get(i), l2.get(i));
				System.out.println("List at" + i + "Match");
			}
			
		}
		catch (Exception e)
		{
			System.out.println("List not matches");
		}
		
	}
	
	/**
	 * To take screenshots.
	 * @param driver
	 * @throws IOException
	 */

    public static String screenShot(WebDriver driver){
        int imagename = 0;
        // Take screenshot and store as a file format             
         File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);           
        try {
        // now copy the  screenshot to desired location using copyFile method
        imagename = (int) System.currentTimeMillis();
        FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\ScreenShots\\"+imagename+".png"));
        System.out.println("timestamp is"+imagename);
        }
        catch (IOException e)
        
        {
          System.out.println(e.getMessage()) ;
        }
        //getting the location of screenshot
       // FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\ScreenShots\\"+imagename+".png"));
       // String extentReportImage;
		String extentReportImage = (System.getProperty("user.dir")+"\\ScreenShots\\"+imagename+".png");
        //System.out.println(extentReportImage);
        return extentReportImage;
          }

	}
	/*
	 * public static void True(Object o) throws Exception { try {
	 * assertTrue(condition); screenShot(driver); } catch (Exception e) {
	 * System.out.println("Assert True exception"); } }
	 * 
	 * public static void False(Object o) throws Exception { try {
	 * assertFalse(o.condition); screenShot(driver); } catch (Exception e) {
	 * System.out.println("Assert False exception"); } }
	 */

