package com.mindtree.kalinga.TicketsHere.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * 
 * @author [your name]
 *
 */
public class ExcelUtils {
	
	File src;
	FileInputStream f;
	XSSFWorkbook wb;
	XSSFSheet sheet1;
	XSSFSheet sheets;
	XSSFRow row;
	XSSFRow row1;
	int cell;
   
	boolean c;
	
	public HashMap<String, List> reading(String address, int sheetNum) throws IOException
	{
	    src=new File(address);
		 f=new FileInputStream(src);
		 wb=new XSSFWorkbook(f);
		sheet1=wb.getSheetAt(sheetNum);
				
		List<String> l=new ArrayList<String>();
		List<String> l1=new ArrayList<String>();
		HashMap<String,List> User=new HashMap<String,List>();
		
		
		
		
		
		for(int j=0;j<=sheet1.getLastRowNum();j++)
		{
		
			row=sheet1.getRow(j);
			
			
			for(int i=0;i<row.getLastCellNum();i++)

		   {
			String username=sheet1.getRow(j).getCell(i).getStringCellValue();
			
			l.add(username);
			//System.out.println(l);
			User.put("Usernames",l);
			//System.out.println(l);
			
			
			String password=sheet1.getRow(j).getCell(++i).getStringCellValue();
			l1.add(password);
			//System.out.println(l1);
			User.put("Passwords",l1);
			//System.out.println(l1);

			
			
					
		}
		
		
		}
		System.out.println("reaxhed");

		return User;
		
	}
	
	
	public boolean search(String address,int sheetNum,String value) throws IOException
	{
		 src=new File(address);
		f=new FileInputStream(src);
		wb=new XSSFWorkbook(f);
		sheet1=wb.getSheetAt(sheetNum);
		
		
		for(int j=0;j<sheet1.getLastRowNum();j++)
		{
		
			row=sheet1.getRow(j);
			
			
			for(int i=0;i<row.getLastCellNum();i++)

		   {
				String entry=row.getCell(i).getStringCellValue();
				//System.out.println(entry);
				if(entry.equals(value))
					
				{
					c=true;
				}
				
		   }
			
	}
		
		return c;	
		

}
	public  void write(String address,int sheetNum,int rowNum,int cellNum,String value) throws Exception
	{
		src=new File(address);
		f=new FileInputStream(src);
		wb=new XSSFWorkbook(f);
		sheet1=wb.getSheetAt(sheetNum);
		
		sheet1.getRow(rowNum).createCell(cellNum).setCellValue(value);
		
		FileOutputStream fos=new FileOutputStream(src);
		
		wb.write(fos);
	}
	
	public ArrayList<String> readAgain(String Address,int sheetNum) throws IOException
	{
		src=new File(Address);
	 f=new FileInputStream(src);
		 wb=new XSSFWorkbook(f);
	 sheets=wb.getSheetAt(sheetNum);
	 ArrayList<String> l2=new ArrayList();
	 
	 int rowCount=sheets.getLastRowNum();
	
	 for(int i=0;i<=rowCount;i++)
		{
			row1=sheets.getRow(i);
			for(int j=0;j<row1.getLastCellNum();j++)
			{
			String data=sheets.getRow(i).getCell(j).getStringCellValue();
		
			l2.add(data);
			
			
			}
			
			
			//System.out.println("data from excel is "+ i +" "+ data);
			//System.out.println("data from excel is "+ i +" "+ data1);
            
			
		}
		
		System.out.println("value is "+l2);
		return l2;
		
		
	}
	
	
	public HashMap<String, List> readingIn(String address, int sheetNum) throws IOException
	{
	    src=new File(address);
		 f=new FileInputStream(src);
		 wb=new XSSFWorkbook(f);
		sheet1=wb.getSheetAt(sheetNum);
				
		List<String> l=new ArrayList<String>();
		List<Double> l1=new ArrayList<Double>();
		HashMap<String,List> User=new HashMap<String,List>();
		
		
		
		
		
		for(int j=0;j<sheet1.getLastRowNum();j++)
		{
		
			row=sheet1.getRow(j);
			
			
			for(int i=0;i<row.getLastCellNum();i++)

		   {
				cell=sheet1.getRow(j).getCell(i).getCellType();
				if(XSSFCell.CELL_TYPE_STRING==cell)
				{
					System.out.println(cell);
			String username=sheet1.getRow(j).getCell(i).getStringCellValue();
			l.add(username);
			User.put("Usernames",l);
				}
				else if(XSSFCell.CELL_TYPE_NUMERIC==cell)
				{
					double password=sheet1.getRow(j).getCell(i).getNumericCellValue();
				    l1.add(password);
				    User.put("Passwords",l1);
				}
				
				/*cell1=sheet1.getRow(j).getCell(++i).getCellType();
				else if(XSSFCell.CELL_TYPE_NUMERIC==cell1)
					
				{
				
		      	double password=sheet1.getRow(j).getCell(++i).getNumericCellValue();
			    l1.add(password);
			    User.put("Passwords",l1);
				
			
				}*/
					
		}
		
		
		}
		
		return User;
		
	}
	
	
	
	

	

}
