package com.mindtree.kalinga.TicketsHere.Base;

import java.util.NoSuchElementException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.InvalidSelectorException;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriverException;

/**
 * 
 * @author M1043081
 *
 */

public class BrowserExceptions {
	
	public void exception()
	{
	try
	{
		
	}
	
	catch(ElementNotVisibleException e)
	{
		e.printStackTrace();
	}

	catch(InvalidSelectorException e)
	{
		e.printStackTrace();
		
	}
	catch(NoSuchElementException e)
	{
		e.printStackTrace();
	}
	catch(NoSuchFrameException f)
	{
		f.printStackTrace();
	}
	catch(NoAlertPresentException f)
	{
		f.printStackTrace();
	}
	catch(NoSuchWindowException f)
	{
		f.printStackTrace();
	}
	catch(StaleElementReferenceException f)
	{
		f.printStackTrace();
		
	}
	catch(TimeoutException f)
	{
		
	}
	catch(WebDriverException f)
	{
		
	}
	
	}
	

}
