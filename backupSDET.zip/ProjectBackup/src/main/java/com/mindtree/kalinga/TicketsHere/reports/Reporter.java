package com.mindtree.kalinga.TicketsHere.reports;

import java.io.File;
import org.testng.ITestResult;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
/**
 * 
 * @author [chaitanya]
 *
 */


public class Reporter {
	ExtentReports report;
	ExtentTest log;
	boolean clean;
	public ExtentTest setupReports(){
		clean = true;
		report= Reporter.setup(report,log,clean);
	    log = report.startTest("TestCase1");
	    System.out.println("created log");
	    return log;
	}
	/*Setup ExtentReports, clean = true for first Testcase, clean = false for Remaining 
	 * 
	 * We have to initiate log for every TestCase
	 * Eg::
	  	clean = true;
		report= extreports.setup(report,log,clean);
	    log = report.startTest(this.getClass().getSimpleName());
	     */
	public static ExtentReports setup(ExtentReports report,ExtentTest log, boolean clean){
		report=new ExtentReports(System.getProperty("user.dir")+"/ExtentReports/extent.html",clean);


	    report.loadConfig(new File(System.getProperty("user.dir")+"/extent-config.xml"));
	    

	    return report;
	    }
	
	
	//For Logging Messages
	public void reportInfo(ExtentTest log, String Info){
		log.log(LogStatus.INFO, Info);
	}
	
	//For Attaching ScreenShots
	public void attachScreenShot(ExtentTest log, String imageName){
		log.log(LogStatus.INFO,"Snapshot : "+ log.addScreenCapture(imageName));
	}
	
	//@AfterMethod
	public void reportStatus(ExtentTest log,ITestResult result){
		if(result.getStatus()==ITestResult.SUCCESS){
			log.log(LogStatus.PASS, "Test Case is passed");
		}
		else if(result.getStatus() == ITestResult.FAILURE){
			log.log(LogStatus.FAIL, "Test Case Failed is "+result.getTestClass());
		}else if(result.getStatus() == ITestResult.SKIP){
			log.log(LogStatus.SKIP, "Test Case Skipped is "+result.getName());
		}
	}
	
	public void flushReport()
	{
		report.flush();

	}
}