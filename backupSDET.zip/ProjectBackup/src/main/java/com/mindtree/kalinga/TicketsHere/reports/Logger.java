package com.mindtree.kalinga.TicketsHere.reports;

import org.apache.log4j.PropertyConfigurator;

/**
 * 
 * @author [your name]
 *
 */

public class Logger {
	  public void LogConfigure(){
   PropertyConfigurator.configure("./Log4j/log4j.properties");
}
}
