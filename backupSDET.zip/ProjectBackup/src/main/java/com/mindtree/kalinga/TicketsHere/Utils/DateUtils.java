package com.mindtree.kalinga.TicketsHere.Utils;


/**
 * 
 * @author M1043081
 *
 */

 class DateUtils {
	
	public void date()
	{
		System.out.println("sample");
	}

}
