package com.mindtree.kalinga.TicketsHere.Locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ModeOfPaymentLocators 
{
	@FindBy(xpath="")
	public
	WebElement debit;
	@FindBy(xpath="//div/div[3]/input")
	public 
	WebElement netBanking;
}
