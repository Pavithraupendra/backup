package com.mindtree.kalinga.TicketsHere.Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.Base.HelperElements;
import com.mindtree.kalinga.TicketsHere.Locators.ChooseBankLocators;
import com.mindtree.kalinga.TicketsHere.Locators.ModeOfPaymentLocators;
import com.mindtree.kalinga.TicketsHere.reports.Reporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class ChooseBankAction {
	WebDriver driver1=Browsers.driver;
	
	ChooseBankLocators  bank=PageFactory.initElements(driver1, ChooseBankLocators.class);
	   
HelperElements h=PageFactory.initElements(driver1,HelperElements.class);
String imgname;
	ExtentReports report;
	ExtentTest log;
	boolean clean;
	Reporter extreports = new Reporter();
	
	public void choosebank()
	{
		h.clickButton(bank.bank);
	}

}
