package com.mindtree.kalinga.TicketsHere.Base;

import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import com.mindtree.kalinga.TicketsHere.Locators.CommonLocators;

/**
 * 
 * @author [M1043037]
 *
 */

public class HelperElements extends CommonLocators
{
	
	WebDriver driver1=Browsers.driver;
	JavascriptExecutor jse;
	Actions actions;
	Action action;
	WebDriver driver;
	
	public HelperElements(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	    jse= (JavascriptExecutor) driver;
	    actions=new Actions(driver);
	    
	}
	//to scroll page horizontal and vertical
	public  void scrollPage(int horizontal, int vertical )
	{
		jse.executeScript("scroll("+horizontal+","+vertical+")");	
	}
	//to scroll to a particular web element
	public void scrollIntoView(WebElement webElement)
	{
		jse.executeScript("arguments[0].scrollIntoView(true);", webElement);
	}
	//to click
	public void clickButton(WebElement webElement)
	{
		webElement.click();
	}
	//to double-click
	public void doubleClick(WebElement webElement)
	{
		actions.doubleClick();
	}
	//to click and hold
	public void clickAndHold(WebElement webElement)
	{
		actions.moveToElement(webElement).clickAndHold();
	}
	
	/**
	 * to sendkeys
	 * @param webElement
	 * @param textData
	 */
	
	public void setText(WebElement webElement,String textData)
	{
		System.out.println(webElement);
		webElement.sendKeys(textData);
	}
	//to mouse-hover and click
	public void mouseHoverAndClick(WebElement target, WebElement subTarget)
	{
		actions.moveToElement(target);
		actions.moveToElement(subTarget).click().build().perform();	
	}
	//to mouse hover and return tool-tip
	public String mouseHoverAndToolTip(WebElement target,String attribute)
	{
		actions.moveToElement(target).perform();
		String toolTip = target.getAttribute(attribute);
		return toolTip;
	}
	//mouse right click
	public void mouseRightClick(WebElement webelement)
	{
		actions.contextClick(webelement);
	}
	//keyboard action control+characters
	public void ctrl(String character)
	{
		actions.keyDown(Keys.CONTROL).sendKeys(character).keyUp(Keys.CONTROL).perform();
	}
	//keyboard action shift+characters
	public void shift(WebElement webElement,String string)
	{
		actions.keyDown(Keys.SHIFT);
		webElement.sendKeys(string);
		actions.keyUp(Keys.SHIFT).perform();
	}
    //keyboard action enter
	public void enter()
	{
		actions.keyDown(Keys.ENTER).keyUp(Keys.ENTER).perform();
	}
	//keyboard action tab
	public void tab(WebElement webElement)
	{
	    webElement.sendKeys(Keys.TAB);
	}
	//to check if button is enable	
	public boolean isEnable(WebElement webElement)
	{
		boolean enable=webElement.isEnabled();
		return enable;
	} 
	//drop down select by visible text
	public void selectByVisibleText(WebElement webElement,String selectText )
	{
		Select dropDown = new Select(webElement);
		dropDown.selectByVisibleText(selectText);
	}
	//drop down select by index
	public void selectByIndex(WebElement webElement,int index)
	{
		Select dropDown = new Select(webElement);
		dropDown.selectByIndex(index);
	}
	//drop down select by value
	public void selectByValue(WebElement webElement,String value)
	{   
		Select dropDown = new Select(webElement);
		dropDown.selectByValue(value);
	}
    //to drag and drop
	public void dragAndDrop(WebElement source,WebElement target)
    {
		actions.dragAndDrop(source, target);
	} 
	//to check if check-box is selected
	public boolean isCheckbox(WebElement element)
	{
		boolean check=element.isSelected();
		return check;
	} 
	//Get the list of web-elements and compare and click(If matches)
	public void listOfElementsInDropDown(WebElement webElement,String string)
	{
		Select dropDown = new Select(webElement);
		List<WebElement> webElements =dropDown.getOptions(); 
		for(WebElement webElement1: webElements)
		{
			if(string.equals(webElement1.getText()))
			{
				webElement1.click();
			}
		}
	} 
}
	

