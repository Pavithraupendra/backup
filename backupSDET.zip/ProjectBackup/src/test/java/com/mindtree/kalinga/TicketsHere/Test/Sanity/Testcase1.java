package com.mindtree.kalinga.TicketsHere.Test.Sanity;

import java.io.IOException;
import java.util.ArrayList;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import org.testng.annotations.Parameters;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;

import com.mindtree.kalinga.TicketsHere.Action.CommonAction;
import com.mindtree.kalinga.TicketsHere.Base.Browsers;



import com.mindtree.kalinga.TicketsHere.Utils.ExcelUtils;

import com.mindtree.kalinga.TicketsHere.reports.*;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.mindtree.kalinga.TicketsHere.helper.TestHelper;

/**
 * 
 * @author [your name]
 *
 */


public class Testcase1 extends TestHelper {
public static WebDriver driver;

Reporter report = new Reporter();
ExtentTest log;

@BeforeTest
public void setupReports(){
log=report.setupReports();
}
	
@Parameters("browser")
	@Test
	public void test(String browsername) throws IOException
	{
	if (browsername.equalsIgnoreCase("chrome")) {
		 driver = Browsers.openchrome();
	} 
	else if(browsername.equalsIgnoreCase("firefox"))
	{
		driver=Browsers.openfirefox();
	}
		
		driver.manage().window().maximize();
		driver.get("http://172.17.120.240:5600");
		CommonAction commonActions = PageFactory.initElements(driver, CommonAction.class);
		ExcelUtils e = PageFactory.initElements(driver, ExcelUtils.class);
		ArrayList<String> l2 = e.readAgain("./src/test/resources/TicketsHere.xlsx", 0);
	
		String firstname = l2.get(0);
		String lastname = l2.get(1);
		String mail = l2.get(2);
		String password = l2.get(3);
		String birthday = l2.get(4);
		String birthyear = l2.get(5);
		String birthmonth = l2.get(6);
		String gender = l2.get(7);
		String mobile = l2.get(8);
		String e_mail = l2.get(9);
	
		commonActions.signUp(firstname, lastname, mail, password, birthday, birthyear, mobile, e_mail);
	}
@AfterMethod
	public void getResult(ITestResult result){
		if(result.getStatus() == ITestResult.FAILURE){
			log.log(LogStatus.FAIL, "Test Case Failed "+result.getInstanceName());
			String imageName = Assertions.screenShot(driver);
			report.attachScreenShot(log, imageName);
		}else if(result.getStatus() == ITestResult.SKIP){

			log.log(LogStatus.SKIP, "Test Case Skipped is "+result.getName());
		}
		report.flushReport();
}

}
