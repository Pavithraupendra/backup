package com.mindtree.kalinga.TicketsHere.Test.Sanity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.mindtree.kalinga.TicketsHere.Action.ChooseBankAction;
import com.mindtree.kalinga.TicketsHere.Action.CommonAction;
import com.mindtree.kalinga.TicketsHere.Action.ModeOfPaymentAction;
import com.mindtree.kalinga.TicketsHere.Action.NetBankingAction;
import com.mindtree.kalinga.TicketsHere.Action.PriceDetailsAction;
import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.Locators.ChooseBankLocators;
import com.mindtree.kalinga.TicketsHere.Locators.ModeOfPaymentLocators;
import com.mindtree.kalinga.TicketsHere.Locators.NetBankingLocators;
import com.mindtree.kalinga.TicketsHere.Utils.ExcelUtils;
import com.mindtree.kalinga.TicketsHere.reports.Assertions;
import com.mindtree.kalinga.TicketsHere.reports.Reporter;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Payment {
	public  WebDriver driver;
	Reporter report = new Reporter();
	ExtentTest log;
	public static HashMap<String,List> h1;

	@BeforeTest
	public void setupReports(){
	log=report.setupReports();
	}
		
	@Parameters("browser")
		@Test
		public void test(String browsername) throws IOException
		{
		if (browsername.equalsIgnoreCase("chrome")) {
			 driver = Browsers.openchrome();
		} 
		else if(browsername.equalsIgnoreCase("firefox"))
		{
			driver=Browsers.openfirefox();
		}
			
			driver.manage().window().maximize();
			driver.get("http://172.17.120.240:5600/book");
			CommonAction commonActions = PageFactory.initElements(driver, CommonAction.class);
			ExcelUtils e = PageFactory.initElements(driver, ExcelUtils.class);
			
			PriceDetailsAction p=PageFactory.initElements(driver, PriceDetailsAction.class);
			ModeOfPaymentAction  mode=PageFactory.initElements(driver, ModeOfPaymentAction.class);
			ChooseBankAction  bank=PageFactory.initElements(driver, ChooseBankAction.class);
			NetBankingAction  details=PageFactory.initElements(driver, NetBankingAction.class);

			
            h1=e.reading("./src/test/resources/TestData.xlsx", 0);
			List l=h1.get("Usernames");
			List l1=h1.get("Passwords");
			String username=(String) l.get(0);
			String password=(String) l1.get(0);
			
	
		
		p.clickmovies();
		mode.netbanking();
		bank.choosebank();
		details.username(username);
		details.password(password);
		details.pay();
		
		
			
		
			
		}
	@AfterMethod
		public void getResult(ITestResult result){
			if(result.getStatus() == ITestResult.FAILURE){
				log.log(LogStatus.FAIL, "Test Case Failed "+result.getInstanceName());
				String imageName = Assertions.screenShot(driver);
				report.attachScreenShot(log, imageName);
			}else if(result.getStatus() == ITestResult.SKIP){

				log.log(LogStatus.SKIP, "Test Case Skipped is "+result.getName());
			}
			report.flushReport();
	}

	}



