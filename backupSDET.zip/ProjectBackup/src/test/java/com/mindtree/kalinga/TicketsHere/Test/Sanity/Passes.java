package com.mindtree.kalinga.TicketsHere.Test.Sanity;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.mindtree.kalinga.TicketsHere.Action.PlayPassesAction;
import com.mindtree.kalinga.TicketsHere.Action.PlaysPageAction;
import com.mindtree.kalinga.TicketsHere.Base.Browsers;
import com.mindtree.kalinga.TicketsHere.Locators.PlaysPageLocators;
import com.mindtree.kalinga.TicketsHere.reports.Reporter;
import com.relevantcodes.extentreports.ExtentTest;

public class Passes {
	
	public  WebDriver driver;

	Reporter report = new Reporter();
	ExtentTest log;

	@BeforeTest
	public void setupReports(){
	log=report.setupReports();
	}
		@Parameters("browser")

		@Test
		public void sample(String browsername) throws IOException {

		

			if (browsername.equalsIgnoreCase("chrome")) {
				 driver = Browsers.openchrome();
			} 
			else if(browsername.equalsIgnoreCase("firefox"))
			{
				driver=Browsers.openfirefox();
			}
			driver.manage().window().maximize();
			driver.get("http://172.17.120.240:5600/plays");
			
			PlaysPageAction p=PageFactory.initElements(driver,PlaysPageAction.class);
			
		   p.bookNow();
			
			PlayPassesAction pp=PageFactory.initElements(driver,PlayPassesAction.class);
			
			pp.entryPass();
			pp.number();
			
			
			
		}

}
